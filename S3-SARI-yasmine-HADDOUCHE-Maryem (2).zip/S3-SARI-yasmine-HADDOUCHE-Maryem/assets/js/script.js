$(document).ready(function() {
    // gestion du menu mobile
    $('.js-menu-toggle').on('click tap', function() {
        $('#main-nav').toggleClass('open'); // ajoute ou retire la classe open pour afficher/masquer le menu 
        $(this).toggleClass('open'); // change létat du bouton 
        
        // change le texte du bouton en fonction de l'etat du menu
        if ($(this).hasClass('open')) {
            $(this).text('FERMER'); // affiche fermer quand le menu est ouvrt 
        } else {
            $(this).text('MENU'); // remet menu quand le menu est fermé 
        }
    });
 });
 